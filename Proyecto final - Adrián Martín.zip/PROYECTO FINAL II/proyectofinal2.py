almacen = []

class Venta:
    def __init__(self,producto,cantidad,unit,fecha):
        self.producto = producto
        self.cantidad = cantidad
        self.unit = unit
        self.fecha = fecha
        
    def __str__(self) -> str:
        print("El producto " + self.producto + " tiene un precio unitario de " + self.unit + " y "+ self.cantidad + " unidades han sido vendidas a fecha de " + self.fecha +"\n")
        
class Ventas:
    def __init__(self,producto,cantidad,unit,fecha,almacen):
        self.producto = producto
        self.cantidad = cantidad
        self.unit = unit
        self.fecha = fecha
        self.almacen = almacen

    def registrar_Venta(self):
        with open('ventas.csv','a', newline='') as v:
                v.write("El producto " + self.producto + " tiene un precio unitario de " + self.unit + " y "+ self.cantidad + " unidades han sido vendidas a fecha de " + self.fecha +"\n")
                
    def consultar_ventas(self):
        f = input("¿Qué fecha quieres buscar? [DD/MM/YYYY]: ")
        print("\n")
        fic = []
        for i in almacen:
            if f == self.fecha:
                return i.__str__()
            else:
                print("No hay ningún libro con esa fecha")      

class ArchivoCSV:
    def __init__(self,producto,cantidad,unit,fecha,almacen):
        self.producto = producto
        self.cantidad = cantidad
        self.unit = unit
        self.fecha = fecha
        self.almacen = almacen
        
    def leer_Archivo(self):
        f = open('ventas.csv')
        print(f.read())
        
    def escribir_Archivo(self):
        with open('ventas.csv','w',newline='') as v:
            for i in almacen:
                v.write("El producto " + i.producto + " tiene un precio unitario de " + i.unit + " y "+ i.cantidad + " unidades han sido vendidas a fecha de "+ i.fecha +"\n")

def menu():
    opcion = 0
    nombre = 0
    cuantos = 0
    unitario = 0
    fecha = 0
    
    while opcion !=4:
        print("\nMENÚ\n")
        print("(1) Registrar una venta")
        print("(2) Consultar ventas por fecha")
        print("(3) Consultar ventas")
        print("(4) Finalizar programa")
        opcion = int(input("\nIntroduce la opción que desea realizar: "))
        if opcion == 1:
            nombre = input("\nNombre del producto: ")
            cuantos = input("Cantidad vendida: ")
            unitario = input("Precio unitario: ")
            fecha = input("La fecha de venta es: ")
            print("\n")
            producto = Venta(nombre,cuantos,unitario,fecha)
            p = Ventas(nombre,cuantos,unitario,fecha,producto)
            p.registrar_Venta()
            almacen.append(producto) 
        elif opcion == 2:
            producto = Venta(nombre,cuantos,unitario,fecha)
            p = Ventas(nombre,cuantos,unitario,fecha,producto)
            almacen.append(p)
            p.consultar_ventas()
        elif opcion == 3:
            producto = Venta(nombre,cuantos,unitario,fecha)
            p = ArchivoCSV(nombre,cuantos,unitario,fecha,producto)
            almacen.append(p)
            p.leer_Archivo()
        elif opcion == 4:
            print("\nCerrando el programa...\n\n")  
        else:
            print("Opción no válida")
            
menu()