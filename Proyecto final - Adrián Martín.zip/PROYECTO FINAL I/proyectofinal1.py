libreria = []
class Libro():
    def __init__(self,titulo,autor,año,paginas,estado):
        self.titulo = titulo
        self.autor = autor
        self.año = año
        self.paginas = paginas
        self.estado = estado
        
    def __str__(self) -> str:
        print("El libro de titulo " + self.titulo + " cuyo autor/a es " + self.autor + " que ha sido publicado en el ano " + self.año + " tiene " + self.paginas + " paginas")

    def escribirFichero(self):
        with open("biblioteca.txt",'w') as b:
            for i in libreria:
                b.write("El libro de titulo " + i.titulo + " cuyo autor/a es " + i.autor + " que ha sido publicado en el ano " + i.año + " tiene " + i.paginas + " paginas\n")

    def leerFichero(self):
        f = open('biblioteca.txt')
        print(f.read())
        
    def cuentapaginas(self):
        contador = 0
        for i in libreria:
            contador += int(i.paginas)
        return print("\nEn la biblioteca hay" ,contador ,"páginas")
    
    def librosxAño(self):
        cuenta = 0
        libro = int(input("Año del que quiere buscar libros: "))
        for i in libreria:
            if libro == int(i.año):
                cuenta += 1
            else:
                print("No hay ningún libro de ese año") 
        return print("Hay",cuenta,"libros con ese año de publicación")
                    
def buscarxTitulo():
    libro = input("\nEscriba el título del libro que desea buscar: ")
    print("\n")
    for i in libreria:
        if i.titulo==libro:
            i.__str__()

def buscarxAutor():
    libro = input("\nEscriba el título del libro que desea buscar: ")
    print("\n")
    for i in libreria:
        if i.autor==libro:
            i.__str__()
 
def imprimir():
    print("Listado de los libros disponibles:\n")
    for i in libreria:
        if i.estado==False:
            i.__str__()

def menu():
    opcion = 0  
    addtitulo = 0
    addautor = 0
    addaño = 0
    addpaginas = 0
    estado = 0
    
    while opcion !=9:
        print("\nMENÚ\n")
        print("(1) Agregar nuevos libros a la biblioteca")
        print("(2) Buscar libros por título")
        print("(3) Buscar libros por autor")
        print("(4) Listar libros recientemente añadidos a la biblioteca")
        print("(5) Escribir libros en fichero")
        print("(6) Cargar datos del fichero")
        print("(7) Cuenta páginas de la biblioteca")
        print("(8) Libros disponibles en un año concreto de publicación")
        print("(9) Finalizar programa")
        opcion = int(input("\nIntroduce la opción que desea realizar: "))
        if opcion == 1:
            addtitulo = input("\nTítulo del libro que desea añadir: ")
            addautor = input("Autor del libro: ")
            addaño = input("Año de publicación: ")
            addpaginas = input("Número de páginas del libro: ")
            print("\n")
            estado = False
            libros = Libro(addtitulo,addautor,addaño,addpaginas,estado)
            libreria.append(libros)
        elif opcion == 2:
            buscarxTitulo()
        elif opcion == 3:
            buscarxAutor()
        elif opcion == 4:
            imprimir()
        elif opcion == 5:
            libros =Libro(addtitulo,addautor,addaño,addpaginas,estado)
            libros.escribirFichero()
        elif opcion == 6:
            libros =Libro(addtitulo,addautor,addaño,addpaginas,estado)
            libros.leerFichero()
        elif opcion == 7:
            libros =Libro(addtitulo,addautor,addaño,addpaginas,estado)
            libros.cuentapaginas()
        elif opcion == 8:
            libros =Libro(addtitulo,addautor,addaño,addpaginas,estado)
            libros.librosxAño()
        elif opcion == 9:
            print("\nCerrando el programa...\n\n")  
        else:
            print("Opción no válida")

menu()
